<!-- rodape -->
	<footer><p>Usuário: Fulano - Acesso em: xx/xx/xxxx xx:xx</p>
	</footer>
	<!-- fim rodape -->
    <script src="../js/index.js"></script>
</body>
</html>