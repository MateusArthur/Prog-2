<p><?=$mensagem;?></p>
<a href="produtoController.php">Voltar para lista de produtos</a>