		<aside class="col-3">
			<h2>Mais pedidos</h2>
			<!-- container de mais pedidos -->
			<div class="lista-produtos">
			
				<!-- um produto -->
                     <div class="produto">     
                     <a href="#">                 
                        <figure>
                            <img src="img/produtos/projetor.jpg" alt="Projetor multimídia">
                            <figcaption>Projetor multimídia
                            <br><span class="precoFinal">R$ 20,00</span>
                            </figcaption>
                        </figure>        
                        </a>            
                    </div>
				<!-- fim produto -->					
				
				<!-- um produto -->
                     <div class="produto"> 
                     <a href="#">                     
                        <figure>
                            <img src="img/produtos/computador.jpg" alt="Computador">
                            <figcaption>Computador
                            <br><span class="precoFinal">R$ 20,00</span>
                            </figcaption>
                        </figure>    
                        </a>                
                    </div>
				<!-- fim produto -->	
						
				<!-- um produto -->
                     <div class="produto">  
                     <a href="#">                    
                        <figure>
                            <img src="img/produtos/default.jpg" alt="Notebook">
                            <figcaption>Notebook
                            <br>De <span class="precoInicial">R$ 40,00</span> por <span class="precoFinal">R$ 20,00</span>
                            </figcaption>
                        </figure>     
                        </a>               
                    </div>
				<!-- fim produto -->	

			</div>									
			<!-- adicione mais produtos --> 
		</aside>