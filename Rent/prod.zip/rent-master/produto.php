<?php include "includes/cabecalho.php"; ?>
	<!-- area central com 3 colunas -->
	<div class="container">
	<?php include "includes/menu_lateral.php"; ?>	
		<section class="col-2">
			<?php	
            	require_once "classes/Produto.php";
            	require_once "includes/functions.php";

            	$produto = new Produto();

            	$id = (int)$_GET['id'];
            	$lista = $produto->consultaProduto($id);
            	echo "<div class=\"prodpage\">";
	            	echo "<h1>" . $lista[0]['nomeProduto'] . "</h1>";
	            	echo "<img src=img/produtos/" . mostraImagem($lista[0]['imagem']) . ">";
	            	if ($lista[0]['desconto'] == 0){
	            		echo "<span class=\"precoFinal\">" . formataPreco($lista[0]['valor']) . "</span>";
	            	} else {
	            		echo "De <span class=\"precoInicial\">" . formataPreco($lista[0]['valor']) . "</span> Por <span class=\"precoFinal\">" .formataPreco($lista[0]['valorFinal']) . "</span>";
	            	}
            ?>

            <form action="adiciona.php">
            	<label>Quantidade: </label><input type="number" min="0" value="1"><br>
            	<input type="submit" value="Adicionar ao carrinho">
            </form>


        	</div>

        	<div class="detalhes">
	           <h4>Detalhes do Produto</h4>
	           <label>Fabricante: <? echo $lista[0]['nomeFabricante']; ?></label><br>
	           <label>Tensão: <? echo $lista[0]['tensao']; ?></label><br>
	           <label>Descrição: <? echo nl2br($lista[0]['descricao']); ?></label><br>
	           <label>Categorias: <? 
	           		$array = ["catMarcenaria", "catJardinagem", "catLimpeza", "catEscritorio", "catMecanica", "catOutros"];
	           		$array2 = ["Marcenaria", "Jardinagem", "Limpeza", "Escritorio", "Mecanica", "Outros"];
	           		for($i = 0; $i < sizeof($array); $i++){
	           			if ($lista[0][$array[$i]]) {
	           				echo $array2[$i] . " ";
	           			}
	           		}
	           ?>
	           </label><br>
	          
	        </div>
					
		</section>
        <?php include "includes/mais_vendidos.php"; ?>
	</div>
	<!-- fim area central -->
	<?php include "includes/rodape.php"; ?>
